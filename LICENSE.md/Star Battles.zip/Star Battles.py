import pygame, random, os
from sprite_maker import Ship
from sprite_maker import Asteroid
from sprite_maker import Star
from sprite_maker import Beam
from sprite_maker import Big_Beam

global carryOn, Ptext, Ttext, timeout, TIME, SCORE

def doRectsOverlap(rect1, rect2):
    for a, b in [(rect1, rect2), (rect2, rect1)]:
        # Check if a's corners are inside b
        if ((isPointInsideRect(a.left, a.top, b)) or
            (isPointInsideRect(a.left, a.bottom, b)) or
            (isPointInsideRect(a.right, a.top, b)) or
            (isPointInsideRect(a.right, a.bottom, b))):
            return True
 
def isPointInsideRect(x, y, rect):
    if (x > rect.left) and (x < rect.right) and (y > rect.top) and (y < rect.bottom):
        return True
    else:
        return False

pygame.mixer.pre_init(44100, 16, 20, 0) #frequency, size, channels, buffersize
pygame.init()

#Colors  ( R )( G )( B )
BLACK  = (  0,   0,   0)
GREEN  = ( 50, 200, 100)
GREY   = (210, 210, 210)
WHITE  = (255, 255, 255)
RED    = (255,   0,   0)
PURPLE = (255,   0, 255)
YELLOW = (255, 255,   0)
CYAN   = (  0, 255, 255)
BLUE   = (  0,   0, 255)
colorList = (RED, GREEN, PURPLE, YELLOW, CYAN, BLUE)

#Screen definition
SCREENWIDTH = 700
SCREENHEIGHT = 500
size = (SCREENWIDTH, SCREENHEIGHT)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("I Dunno, A Racing Game")

# Images
Galaxy = pygame.image.load('Title Galaxy.jpg').convert()
Galaxy = pygame.transform.scale(Galaxy, (700, 500))
Title_Galaxy = pygame.image.load('galaxy.jpg').convert()
Title_Galaxy = pygame.transform.scale(Title_Galaxy, (700, 500))

#Sounds
Crunch = pygame.mixer.Sound('Crunch.wav')
Pew = pygame.mixer.Sound('Pew.wav')
Win = pygame.mixer.Sound('Win.wav')
Oops = pygame.mixer.Sound('Oops.wav')

# Mis. definitions
traffic_speedy = 1
decor_speedy = 10
color = 1
touchingwall = 0
BEAMSIZEx = 3
BEAMSIZEy = 12
TIME = 500
SCORE = 0
LIVES = 3
beams = []
asteroids = []
timeout = False
RemP = False
Rem1 = False
Rem2 = False
Rem3 = False
Rem4 = False
Crash1 = False
Crash2 = False
Crash3 = False
Crash4 = False

#Text
fontObj = pygame.font.Font('orbitron-black.ttf', 70)
textSurfaceObj = fontObj.render('Paused', True, WHITE, BLACK)
textRectObj = textSurfaceObj.get_rect()
textRectObj.center = (350, 250)
Ptext = "off"

titlefont = pygame.font.Font('orbitron-black.ttf', 100)
titletextSurface = titlefont.render("Star Battles", True, WHITE)
titletextRect = titletextSurface.get_rect()
titletextRect.center = (350, 150)

title2font = pygame.font.Font('orbitron-black.ttf', 50)
title2textSurface = title2font.render("press P to start", True, WHITE)
title2textRect = title2textSurface.get_rect()
title2textRect.center = (350, 350)

timefont = pygame.font.Font('orbitron-black.ttf', 20)
timetextSurface = timefont.render("Time: ", True, BLACK)
timetextRect = timetextSurface.get_rect()
timetextRect.center = (350, 20)

scorefont = pygame.font.Font('orbitron-black.ttf', 20)
scoretextSurface = scorefont.render("0", True, WHITE)
scoretextRect = scoretextSurface.get_rect()
scoretextRect.center = (20, 20)

livesfont = pygame.font.Font('orbitron-black.ttf', 20)
livestextSurface = livesfont.render("0", True, WHITE)
livestextRect = livestextSurface.get_rect()
livestextRect.center = (SCREENWIDTH - 100, 20)

timetextSurface = timefont.render(("Time: " +(str(TIME))), True, WHITE)
scoretextSurface = scorefont.render(("Score: " +(str(SCORE))), True, WHITE)
livestextSurface = livesfont.render(("Lives: " +(str(LIVES))), True, WHITE)

#Sprites
playerCar = Ship(60, 80, 70)
playerCar.rect.x = 360
playerCar.rect.y = SCREENHEIGHT - 100
playerCar_list = pygame.sprite.Group()
playerCar_list.add(playerCar)

## Specifically the asteroid sprites
car1 = Asteroid(60, 0, random.randint(50, 100))
car1.rect.x = 50
car1.rect.y = -200
car1_list = pygame.sprite.Group()
car1_list.add(car1)

car2 = Asteroid(60, 0, random.randint(50, 100))
car2.rect.x = 200
car2.rect.y = -700
car2_list = pygame.sprite.Group()
car2_list.add(car2)

car3 = Asteroid(60, 0, random.randint(50, 100))
car3.rect.x = 350
car3.rect.y = -400
car3_list = pygame.sprite.Group()
car3_list.add(car3)

car4 = Asteroid(60, 0, random.randint(50, 100))
car4.rect.x = 500
car4.rect.y = -1000
car4_list = pygame.sprite.Group()
car4_list.add(car4)

## Specifically the star sprites
tree1 = Star(60, 0, random.randint(50, 100))
tree1.rect.x = -300 
tree1.rect.y = -100
tree2 = Star(60, 0, random.randint(50, 100))
tree2.rect.x = 0 
tree2.rect.y = -400
tree3 = Star(60, 0, random.randint(50, 100))
tree3.rect.x = 300
tree3.rect.y = -200
tree4 = Star(60, 0, random.randint(50, 100))
tree4.rect.x = 600
tree4.rect.y = -600

# This will be a list that will contain all the sprites we intend to use in our game.
## Add the car to the list of objects
all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(playerCar)
all_sprites_list.add(car1)
all_sprites_list.add(car2)
all_sprites_list.add(car3)
all_sprites_list.add(car4)
all_sprites_list.add(tree1)
all_sprites_list.add(tree2) 
all_sprites_list.add(tree3)
all_sprites_list.add(tree4)

## Just the oncoming asteroids
all_coming_cars = pygame.sprite.Group()
all_coming_cars.add(car1)
all_coming_cars.add(car2)
all_coming_cars.add(car3)
all_coming_cars.add(car4)

## Just decorations to make the game look better
all_coming_decor = pygame.sprite.Group()
all_coming_decor.add(tree1)
all_coming_decor.add(tree2)
all_coming_decor.add(tree3)
all_coming_decor.add(tree4)

rect_beams = pygame.sprite.Group()


Ship_sensor = {'rect': pygame.Rect(playerCar.rect.x + 16, playerCar.rect.y + 5, 50, 73)}

A1 = {'rect': pygame.Rect(car1.rect.x + 60, car1.rect.y + 100, 46, 33)}
A2 = {'rect': pygame.Rect(car2.rect.x + 60, car2.rect.y + 100, 46, 33)}
A3 = {'rect': pygame.Rect(car3.rect.x + 60, car3.rect.y + 100, 46, 33)}
A4 = {'rect': pygame.Rect(car4.rect.x + 60, car4.rect.y + 100, 46, 33)}
asteroids.append(A1)
asteroids.append(A2)
asteroids.append(A3)
asteroids.append(A4)

##for i in range(50):
##    beams.append(pygame.Rect(random.randint(0, SCREENWIDTH - BEAMSIZEx), random.randint(0, SCREENHEIGHT - BEAMSIZEy), BEAMSIZEx, BEAMSIZEy))

everyOn = True
carryOn = False
clock = pygame.time.Clock() 

# Title Screen
def Title_screen():
    global Ttext, timeout, TIME, SCORE
    carryOn = False
    SCORE = 0
    Ttext = "on"
    pygame.mixer.music.stop()
    Titlesong = pygame.mixer.music.load('Dance Energetic.wav')
    pygame.mixer.music.play(-1)
    screen.blit(Title_Galaxy, (0, 0))
    playerCar.rect.x = 360
    car1.rect.y = -200
    car2.rect.y = -700
    car3.rect.y = -400
    car4.rect.y = -1000

def Pause():
    global carryOn, Ptext, Ttext
    carryOn = False
    Ptext = "on"
    pygame.mixer.music.stop()
    Pausesong = pygame.mixer.music.load('Dance Energetic.wav')
    pygame.mixer.music.play(-1)

def Unpause():
    global carryOn, Ptext, Ttext
    carryOn = True
    Ptext = "off"
    Ttext = "off"
    pygame.mixer.music.stop()
    Playsong = pygame.mixer.music.load('Chill.wav')
    pygame.mixer.music.play(-1)

Title_screen()

# Anything that updates ever
while everyOn:
    '''os.system('cls')'''
    '''print (traffic_speedy)'''
    # To pause/quit the game
    key = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            everyOn = False
        if event.type == pygame.KEYDOWN:
            if carryOn == True and event.key == pygame.K_p:
                if timeout == True:
                    timeout = False
                Pause()
            elif carryOn == False and event.key == pygame.K_p:
                if timeout == True:
                    timeout = False
                Unpause()
            
            NEWBEAMx1 = playerCar.rect.x + 40
            if carryOn == True and event.key == pygame.K_SPACE or event.key == pygame.K_u: 
                beams.append(pygame.Rect(NEWBEAMx1, SCREENHEIGHT - 70, BEAMSIZEx, BEAMSIZEy))
                Newbiem = (rect_beams.add(Beam((NEWBEAMx1 - 10), (SCREENHEIGHT - 100), BEAMSIZEx, BEAMSIZEy, 20)))
                Pew.play()
            elif carryOn == True and event.key == pygame.K_i:
                beams.append(pygame.Rect(NEWBEAMx1, SCREENHEIGHT - 70, BEAMSIZEx + 10, BEAMSIZEy + 40))
                Newbiem = (rect_beams.add(Big_Beam((NEWBEAMx1 - 45), (SCREENHEIGHT - 125), BEAMSIZEx, BEAMSIZEy, 20)))
                Pew.play()
            elif carryOn == True and event.key == pygame.K_o:
                for i in range(40):
                    NEWBEAMx2 = random.randint(0, SCREENWIDTH - BEAMSIZEx)
                    beams.append(pygame.Rect(NEWBEAMx2, SCREENHEIGHT, BEAMSIZEx, BEAMSIZEy))
                    Newbiem = (rect_beams.add(Beam((NEWBEAMx2 - 10), (SCREENHEIGHT - 30), BEAMSIZEx, BEAMSIZEy, 20)))
                    Pew.play()
    if Ttext == "on":
        screen.blit(Title_Galaxy, (0, 0))
    else:
        screen.blit(Galaxy, (0, 0))

    Ship_sensor = {'rect': pygame.Rect(playerCar.rect.x + 16, playerCar.rect.y + 5, 50, 73)}

    A1 = {'rect': pygame.Rect(car1.rect.x + 60, car1.rect.y + 100, 36, 33)}
    A2 = {'rect': pygame.Rect(car2.rect.x + 60, car2.rect.y + 100, 36, 33)}
    A3 = {'rect': pygame.Rect(car3.rect.x + 60, car3.rect.y + 100, 36, 33)}
    A4 = {'rect': pygame.Rect(car4.rect.x + 60, car4.rect.y + 100, 36, 33)}

    asteroids = []
    if Rem1 != True:
        asteroids.append(A1)
    if Rem2 != True:
        asteroids.append(A2)
    if Rem3 != True:
        asteroids.append(A3)
    if Rem4 != True:
        asteroids.append(A4)
 
    # Beam collision
    for beam in beams[:]:
        if doRectsOverlap(A1['rect'], beam):
            beams.remove(beam)
            if Rem1 == False:
                asteroids.remove(A1)
            Rem1 = True
            SCORE += 100
            Crunch.play()
        elif doRectsOverlap(A2['rect'], beam):
            beams.remove(beam)
            if Rem2 == False:
                asteroids.remove(A2)
            Rem2 = True
            SCORE += 100
            Crunch.play()
        elif doRectsOverlap(A3['rect'], beam):
            beams.remove(beam)
            if Rem3 == False:
                asteroids.remove(A3)
            Rem3 = True
            SCORE += 100
            Crunch.play()
        elif doRectsOverlap(A4['rect'], beam):
            beams.remove(beam)
            if Rem4 == False:
                asteroids.remove(A4)
            Rem4 = True
            SCORE += 100
            Crunch.play()
##        elif doRectsOverlap(Ship_sensor['rect'], beam):
##            beams.remove(beam)

    # Asteroid collision
##    if doRectsOverlap(A1['rect'], Ship_sensor["rect"]):
##        asteroids.remove(A1)
##        remove = (A1)
##        if Crash1 == False:
##            Crash1 = True
##        else:
##            asteroids.remove(A1)
##            if LIVES >=1:
##                LIVES -= 1
##            else:
##                carryOn = False
##                LIVES = 3
##    elif doRectsOverlap(A2['rect'], Ship_sensor["rect"]):
##        asteroids.remove(A2)
##        remove = (A2)
##        if Crash2 == False:
##            Crash2 = True
##        else:
##            asteroids.remove(A2)
##            if LIVES >=1:
##                LIVES -= 1
##            else:
##                carryOn = False
##                LIVES = 3
##    elif doRectsOverlap(A3['rect'], Ship_sensor["rect"]):
##        asteroids.remove(A3)
##        remove = (A3)
##        if Crash3 == False:
##            Crash3 = True
##        else:
##            asteroids.remove(A3)
##            if LIVES >=1:
##                LIVES -= 1
##            else:
##                carryOn = False
##                LIVES = 3
##    elif doRectsOverlap(A4['rect'], Ship_sensor["rect"]):
##        asteroids.remove(A4)
##        remove = (A4)
##        if Crash4 == False:
##            Crash4 = True
##        else:
##            asteroids.remove(A4)
##            if LIVES >=1:
##                LIVES -= 1
##            else:
##                carryOn = False
##                LIVES = 3
            
####    for asteroid in asteroids[:]:
####        if doRectsOverlap(Ship_sensor["rect"], asteroid["rect"]):
####            asteroids.remove(asteroid)
####            remove = (asteroid)
##            if Crash1 = False:
##                Crash1 = True
##            else:
##                asteroids.remove(A1)
##                if LIVES >=1:
##                    LIVES -= 1
##                else:
##                    carryOn = False
##                    LIVES = 3
        
    # Showing the hitboxes.
    for i in range(len(beams)):
        beams[i][1] -= 20
##        pygame.draw.rect(screen, RED, beams[i])
##        if beams[i][1] >= -60:
##            beams.remove(beam)

##    for h in range(len(asteroids)):
##        pygame.draw.rect(screen, WHITE, asteroids[h]['rect'])
##
##    pygame.draw.rect(screen, BLUE, Ship_sensor['rect'])

    if Ptext == "on":
        screen.blit(textSurfaceObj, textRectObj)

    if Ttext == "on":
        screen.blit(titletextSurface, titletextRect)
        screen.blit(title2textSurface, title2textRect)

    # If game is not paused
    if carryOn:
        #pygame.mixer.pause()

        if TIME <= 0:
            carryOn = False
            timeout = True
            TIME = 500
            if SCORE > 0:
                Win.play()
            else:
                Oops.play()
            Title_screen()
        else:
            TIME -= 1
        
        # Controls
        if key[pygame.K_a]:
            playerCar.moveLeft(5)
        if key[pygame.K_d]:
             playerCar.moveRight(5)
        if key[pygame.K_w] and traffic_speedy <= 2.5:
            traffic_speedy += 0.02
        if key[pygame.K_s] and traffic_speedy >= -1.5:
            traffic_speedy -= 0.02

        # Game Logic
        for car in all_coming_cars:
            car.moveForward(traffic_speedy)

        for beam in rect_beams:
            beam.moveForward(20)

        if car1.rect.y > SCREENHEIGHT:
            car1.changeSpeed(random.randint(50, 100)) 
            car1.rect.y = -200
            Rem1 = False
            Crash1 = False
            SCORE -= 100
        if car2.rect.y > SCREENHEIGHT:
            car2.changeSpeed(random.randint(50, 100))
            car2.rect.y = -200
            Rem2 = False 
            Crash2 = False
            SCORE -= 100
        if car3.rect.y > SCREENHEIGHT:
            car3.changeSpeed(random.randint(50, 100))
            car3.rect.y = -200
            Rem3 = False
            Crash3 = False
            SCORE -= 100
        if car4.rect.y > SCREENHEIGHT:
            car4.changeSpeed(random.randint(50, 100))
            car4.rect.y = -200
            Rem4 = False
            Crash4 = False
            SCORE -= 100

        for tree in all_coming_decor:
            tree.moveForward(decor_speedy) 
            if tree.rect.y > SCREENHEIGHT + 500:
                tree.rect.y = -1000
        
        ## Collision
        if playerCar.rect.x >= 549 and touchingwall == 0:
            touchingwall = 1
        elif playerCar.rect.x <= 0 and touchingwall == 0:
            touchingwall = 1
        elif playerCar.rect.x > 0 and playerCar.rect.x < 519:
            touchingwall = 0

        all_coming_decor.update()
        all_coming_decor.draw(screen)
        rect_beams.update()
        rect_beams.draw(screen)
        if RemP == False:
            playerCar_list.update()
            playerCar_list.draw(screen)
        if Rem1 == False:
            car1_list.update()
            car1_list.draw(screen)
        if Rem2 == False:
            car2_list.update()
            car2_list.draw(screen)
        if Rem3 == False:
            car3_list.update()
            car3_list.draw(screen)
        if Rem4 == False:
            car4_list.update()
            car4_list.draw(screen)
            
        timetextSurface = timefont.render(("Time: " +(str(TIME))), True, WHITE)
        scoretextSurface = scorefont.render(("Score: " +(str(SCORE))), True, WHITE)
        livestextSurface = livesfont.render(("Lives: " +(str(LIVES))), True, WHITE)
    else:
        pygame.mixer.unpause()

    screen.blit(timetextSurface, timetextRect)
    screen.blit(scoretextSurface, scoretextRect)
    screen.blit(livestextSurface, livestextRect)

    # Refresh Screen
    pygame.display.flip()

    # FPS
    clock.tick(60)

pygame.quit()

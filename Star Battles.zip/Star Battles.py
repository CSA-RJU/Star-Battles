import pygame, random, os
from sprite_maker import Ship
from sprite_maker import Asteroid
from sprite_maker import Star
from sprite_maker import Beam
from sprite_maker import Big_Beam

global carryOn, Ptext, Ttext, timeout, TIME, SCORE, LIVES, traffic_speedy, speed_points, all_scoreslist1, all_scoreslist2

def doRectsOverlap(rect1, rect2):
    for a, b in [(rect1, rect2), (rect2, rect1)]:
        # Check if a's corners are inside b
        if ((isPointInsideRect(a.left, a.top, b)) or
            (isPointInsideRect(a.left, a.bottom, b)) or
            (isPointInsideRect(a.right, a.top, b)) or
            (isPointInsideRect(a.right, a.bottom, b))):
            return True

def isPointInsideRect(x, y, rect):
    if (x > rect.left) and (x < rect.right) and (y > rect.top) and (y < rect.bottom):
        return True
    else:
        return False

pygame.mixer.pre_init(44100, 16, 20, 0) #frequency, size, channels, buffersize
pygame.init()

#Colors  ( R )( G )( B )
BLACK  = (  0,   0,   0)
GREEN  = ( 50, 200, 100)
GREY   = (210, 210, 210)
WHITE  = (255, 255, 255)
RED    = (255,   0,   0)
PURPLE = (255,   0, 255)
YELLOW = (255, 255,   0)
CYAN   = (  0, 255, 255)
BLUE   = (  0,   0, 255)
colorList = (RED, GREEN, PURPLE, YELLOW, CYAN, BLUE)

# Mis. definitions
traffic_speedy = 1
decor_speedy = 10
speed_points = 0
color = 1
PU_type = 1
touchingwall = 0
BEAMSIZEx = 3
BEAMSIZEy = 12
TIME = 5000
SCORE = 0
LIVES = 3
mousexy = (0, 0)
beams = []
asteroids = []
timeout = False
RemP_image = False
Rem1_rect = False
Rem2_rect = False
Rem3_rect = False
Rem4_rect = False
Rem1_image = False
Rem2_image = False
Rem3_image = False
Rem4_image = False
RemPU_rect = False
Crash1 = False
Crash2 = False
Crash3 = False
Crash4 = False
HTPtext = "off"

#Screen definition
SCREENWIDTH = 700
SCREENHEIGHT = 500
size = (SCREENWIDTH, SCREENHEIGHT)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("I Dunno, A Racing Game")

# Images
Galaxy = pygame.image.load('Title Galaxy.jpg').convert()
Galaxy = pygame.transform.scale(Galaxy, (700, 500))
Title_Galaxy = pygame.image.load('galaxy.jpg').convert()
Title_Galaxy = pygame.transform.scale(Title_Galaxy, (700, 500))

How_to_Play = pygame.image.load('How to Play.jpg').convert()
How_to_Play = pygame.transform.scale(How_to_Play, (700, 500))

## Power ups
Time_Up = pygame.image.load('Time +.png').convert()
#Time_Up = pygame.transform.scale(Time_Up, (50, 50))

#Sounds
Crunch = pygame.mixer.Sound('Crunch.wav')
Pew = pygame.mixer.Sound('Pew.wav')
Win = pygame.mixer.Sound('Win.wav')
Lose = pygame.mixer.Sound('Lose.wav')
Collect = pygame.mixer.Sound('Coin.wav')

#Text
fontObj = pygame.font.Font('orbitron-black.ttf', 70)
textSurfaceObj = fontObj.render('Paused', True, WHITE, BLACK)
textRectObj = textSurfaceObj.get_rect()
textRectObj.center = (350, 250)
Ptext = "off"

titlefont = pygame.font.Font('orbitron-black.ttf', 100)
titletextSurface = titlefont.render("Star Battles", True, WHITE)
titletextRect = titletextSurface.get_rect()
titletextRect.center = (350, 100)

title2font = pygame.font.Font('orbitron-black.ttf', 50)
title2textSurface = title2font.render("Press P to start", True, WHITE)
title2textRect = title2textSurface.get_rect()
title2textRect.center = (450, 325)

HTPfont = pygame.font.Font('orbitron-black.ttf', 50)
HTPtextSurface = HTPfont.render("How to play", True, WHITE)
HTPtextRect = HTPtextSurface.get_rect()
HTPtextRect.center = (450, 200)

timefont = pygame.font.Font('orbitron-black.ttf', 20)
timetextSurface = timefont.render("Time: ", True, BLACK)
timetextRect = timetextSurface.get_rect()
timetextRect.center = (350, 20)

scorefont = pygame.font.Font('orbitron-black.ttf', 20)
scoretextSurface = scorefont.render("0", True, WHITE)
scoretextRect = scoretextSurface.get_rect()
scoretextRect.center = (20, 20)

livesfont = pygame.font.Font('orbitron-black.ttf', 20)
livestextSurface = livesfont.render("0", True, WHITE)
livestextRect = livestextSurface.get_rect()
livestextRect.center = (SCREENWIDTH - 100, 20)

timetextSurface = timefont.render(("Time: " +(str(TIME))), True, WHITE)
scoretextSurface = scorefont.render(("Score: " +(str(SCORE))), True, WHITE)
livestextSurface = livesfont.render(("Lives: " +(str(LIVES))), True, WHITE)

topfont = pygame.font.Font('orbitron-black.ttf', 10)
toptextSurface = topfont.render("Top Scores:", True, BLACK)
toptextRect = toptextSurface.get_rect()
toptextRect.center = (80, 160)

S1font = pygame.font.Font('orbitron-black.ttf', 15)
S1textSurface = S1font.render("0", True, BLACK)
S1textRect = S1textSurface.get_rect()
S1textRect.center = (50, 180)

S2font = pygame.font.Font('orbitron-black.ttf', 15)
S2textSurface = S2font.render("0", True, BLACK)
S2textRect = S2textSurface.get_rect()
S2textRect.center = (50, 200)

S3font = pygame.font.Font('orbitron-black.ttf', 15)
S3textSurface = S3font.render("0", True, BLACK)
S3textRect = S3textSurface.get_rect()
S3textRect.center = (50, 220)

S4font = pygame.font.Font('orbitron-black.ttf', 15)
S4textSurface = S4font.render("0", True, BLACK)
S4textRect = S4textSurface.get_rect()
S4textRect.center = (50, 240)

S5font = pygame.font.Font('orbitron-black.ttf', 15)
S5textSurface = S5font.render("0", True, BLACK)
S5textRect = S5textSurface.get_rect()
S5textRect.center = (50, 260)

S6font = pygame.font.Font('orbitron-black.ttf', 15)
S6textSurface = S6font.render("0", True, BLACK)
S6textRect = S6textSurface.get_rect()
S6textRect.center = (50, 280)

S7font = pygame.font.Font('orbitron-black.ttf', 15)
S7textSurface = S7font.render("0", True, BLACK)
S7textRect = S7textSurface.get_rect()
S7textRect.center = (50, 300)

S8font = pygame.font.Font('orbitron-black.ttf', 15)
S8textSurface = S8font.render("0", True, BLACK)
S8textRect = S8textSurface.get_rect()
S8textRect.center = (50, 320)

S9font = pygame.font.Font('orbitron-black.ttf', 15)
S9textSurface = S9font.render("0", True, BLACK)
S9textRect = S9textSurface.get_rect()
S9textRect.center = (50, 340)

S10font = pygame.font.Font('orbitron-black.ttf', 15)
S10textSurface = S10font.render("0", True, BLACK)
S10textRect = S10textSurface.get_rect()
S10textRect.center = (50, 360)

#Sprites
playerCar = Ship(60, 80, 70)
playerCar.rect.x = 360
playerCar.rect.y = SCREENHEIGHT - 100
playerCar_list = pygame.sprite.Group()
playerCar_list.add(playerCar)

## Specifically the asteroid sprites
car1 = Asteroid(60, 0, random.randint(50, 100))
car1.rect.x = 50
car1.rect.y = -200
car1_list = pygame.sprite.Group()
car1_list.add(car1)

car2 = Asteroid(60, 0, random.randint(50, 100))
car2.rect.x = 200
car2.rect.y = -700
car2_list = pygame.sprite.Group()
car2_list.add(car2)

car3 = Asteroid(60, 0, random.randint(50, 100))
car3.rect.x = 350
car3.rect.y = -400
car3_list = pygame.sprite.Group()
car3_list.add(car3)

car4 = Asteroid(60, 0, random.randint(50, 100))
car4.rect.x = 500
car4.rect.y = -1000
car4_list = pygame.sprite.Group()
car4_list.add(car4)

## Specifically the star sprites
tree1 = Star(60, 0, random.randint(50, 100))
tree1.rect.x = -300
tree1.rect.y = -100
tree2 = Star(60, 0, random.randint(50, 100))
tree2.rect.x = 0
tree2.rect.y = -400
tree3 = Star(60, 0, random.randint(50, 100))
tree3.rect.x = 300
tree3.rect.y = -200
tree4 = Star(60, 0, random.randint(50, 100))
tree4.rect.x = 600
tree4.rect.y = -600

# This will be a list that will contain all the sprites we intend to use in our game.
## Add the car to the list of objects
all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(playerCar)
all_sprites_list.add(car1)
all_sprites_list.add(car2)
all_sprites_list.add(car3)
all_sprites_list.add(car4)
all_sprites_list.add(tree1)
all_sprites_list.add(tree2)
all_sprites_list.add(tree3)
all_sprites_list.add(tree4)

## Just the oncoming asteroids
all_coming_cars = pygame.sprite.Group()
all_coming_cars.add(car1)
all_coming_cars.add(car2)
all_coming_cars.add(car3)
all_coming_cars.add(car4)

## Just decorations to make the game look better
all_coming_decor = pygame.sprite.Group()
all_coming_decor.add(tree1)
all_coming_decor.add(tree2)
all_coming_decor.add(tree3)
all_coming_decor.add(tree4)

rect_beams = pygame.sprite.Group()


Ship_sensor = {'rect': pygame.Rect(playerCar.rect.x + 16, playerCar.rect.y + 5, 50, 73)}

A1 = {'rect': pygame.Rect(car1.rect.x + 60, car1.rect.y + 100, 46, 33)}
A2 = {'rect': pygame.Rect(car2.rect.x + 60, car2.rect.y + 100, 46, 33)}
A3 = {'rect': pygame.Rect(car3.rect.x + 60, car3.rect.y + 100, 46, 33)}
A4 = {'rect': pygame.Rect(car4.rect.x + 60, car4.rect.y + 100, 46, 33)}
asteroids.append(A1)
asteroids.append(A2)
asteroids.append(A3)
asteroids.append(A4)

Power_up_x = random.randrange(0, 630)
Power_up_y = -5000
Power_up = {'rect': pygame.Rect(Power_up_x, Power_up_y, 50, 60)}

##for i in range(50):
##    beams.append(pygame.Rect(random.randint(0, SCREENWIDTH - BEAMSIZEx), random.randint(0, SCREENHEIGHT - BEAMSIZEy), BEAMSIZEx, BEAMSIZEy))

everyOn = True
carryOn = False
clock = pygame.time.Clock()

# Opens the file of top scores
def Check_scores1():
    global all_scoreslist1, SCORE
    all_scoreslist1 = [] 
    open_scores = open("Star_Battles_HScores.txt", "r")
    line = open_scores.readline() #Reads the first line once to get it started.
    while line:  # Assures the program runs through the whole script.
        all_scoreslist1.append(line)
        line = open_scores.readline()  # Assures that the program checks more than one line.
##    all_scorestext = (("1: " + str(all_scoresstring[0])) + "\n 2: " + (str(all_scoresstring[1])) + "\n 3: " + (str(all_scoresstring[2])) + "\n 4: " + (str(all_scoresstring[3])) + "\n 5: " + (str(all_scoresstring[4])) + "\n 6: " + (str(all_scoresstring[5])) + "\n 7: " + (str(all_scoresstring[6])) + "\n 8: " + (str(all_scoresstring[7])) + "\n 9: " + (str(all_scoresstring[8])) + "\n 10: " + (str(all_scoresstring[9])))
    open_scores.close()
    Check_scores2()

def Check_scores2():
    global all_scoreslist1, all_scoreslist2, SCORE
    done = False
    previous_score = 0
    all_scoreslist2 = []
    for x in all_scoreslist1:  # Checks every line separated into a list.
        linesplit = x.split(":")
        if linesplit[0] == '1'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
            
        if linesplit[0] == '2'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '2'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '3'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '3'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '4'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '4'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '5'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '5'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '6'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '6'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '7'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '7'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '8'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '8'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '9'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True 
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '9'and done != False:
            all_scoreslist2.append(previous_score[1])
            
        if linesplit[0] == '10'and done != True:
            if SCORE > int(linesplit[1]):
                adder = int(SCORE)
                previous_score = int(SCORE)
                done = True
            else:
                adder = linesplit[1]
                done = False
            all_scoreslist2.append(adder)
        elif linesplit[0] == '10'and done != False:
            all_scoreslist2.append(previous_score[1])
        previous_score = linesplit
    all_scoreslist1 = [("1:" + (str(all_scoreslist2[0]))), ("2:" + (str(all_scoreslist2[1]))), ("3:" + (str(all_scoreslist2[2]))), ("4:" + (str(all_scoreslist2[3]))), ("5:" + (str(all_scoreslist2[4]))), ("6:" + (str(all_scoreslist2[5]))), ("7:" + (str(all_scoreslist2[6]))), ("8:" + (str(all_scoreslist2[7]))), ("9:" + (str(all_scoreslist2[8]))), ("10:" + (str(all_scoreslist2[9])))]
    Write_scores()
    
def Write_scores():
    global all_scoreslist1
    scorecheck = open("Star_Battles_HScores.txt", "w")
    for x in all_scoreslist1:
        scorecheck.write(str(x)) #Shows what was tryed, when, and if it was successful, with spacing inbetween.
        scorecheck.write("\n") #This is so that the .txt file does not just have one big line of entrys.
    scorecheck.close()

# Title Screen
def Title_screen():
    global carryOn, Ttext, timeout, TIME, SCORE, LIVES, traffic_speedy, speed_points
    carryOn = False
    SCORE = 0
    LIVES = 3
    TIME = 5001
    Ttext = "on" 
    
    pygame.mixer.music.stop()
    Titlesong = pygame.mixer.music.load('Dance Energetic.wav')
    pygame.mixer.music.play(-1) 
    
    screen.blit(Title_Galaxy, (0, 0))
    traffic_speedy = 1
    speed_points = 0
    
    playerCar.rect.x = 360
    car1.rect.y = -200
    car2.rect.y = -700
    car3.rect.y = -400
    car4.rect.y = -1000

def Pause():
    global carryOn, Ptext, Ttext
    carryOn = False
    Ptext = "on"

def Unpause():
    global carryOn, Ptext, Ttext
    carryOn = True
    Ptext = "off"
    Ttext = "off"
    pygame.mixer.music.stop()
    Playsong = pygame.mixer.music.load('Chill.wav')
    pygame.mixer.music.play(-1)

Check_scores1()
Title_screen()

# Anything that updates ever
while everyOn:
    '''os.system('cls')'''
    '''print (traffic_speedy)'''
    # To pause/quit the game
    key = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            everyOn = False
        if event.type == pygame.KEYDOWN:
            if carryOn == True and event.key == pygame.K_p:
                if timeout == True:
                    timeout = False
                Pause()
            elif carryOn == False and event.key == pygame.K_p:
                if timeout == True:
                    timeout = False
                Unpause()

            NEWBEAMx1 = playerCar.rect.x + 40
            if carryOn == True and event.key == pygame.K_SPACE or carryOn == True and event.key == pygame.K_u:
                beams.append(pygame.Rect(NEWBEAMx1, SCREENHEIGHT - 70, BEAMSIZEx, BEAMSIZEy))
                Newbiem = (rect_beams.add(Beam((NEWBEAMx1 - 10), (SCREENHEIGHT - 100), BEAMSIZEx, BEAMSIZEy, 20)))
                Pew.play()
            if carryOn == True and event.key == pygame.K_i:
                beams.append(pygame.Rect(NEWBEAMx1, SCREENHEIGHT - 70, BEAMSIZEx + 10, BEAMSIZEy + 40))
                Newbiem = (rect_beams.add(Big_Beam((NEWBEAMx1 - 45), (SCREENHEIGHT - 125), BEAMSIZEx, BEAMSIZEy, 20)))
                Pew.play()
            if carryOn == True and event.key == pygame.K_o:
                for i in range(40):
                    NEWBEAMx2 = random.randint(0, SCREENWIDTH - BEAMSIZEx)
                    beams.append(pygame.Rect(NEWBEAMx2, SCREENHEIGHT, BEAMSIZEx, BEAMSIZEy))
                    Newbiem = (rect_beams.add(Beam((NEWBEAMx2 - 10), (SCREENHEIGHT - 30), BEAMSIZEx, BEAMSIZEy, 20)))
                    Pew.play()
        
        if event.type == pygame.MOUSEMOTION:
            mousexy = event.pos
        if event.type == 5:
            if Ttext == "on" and HTPtext == "off":
                if mousexy[0] > 270 and mousexy[0] < (270 + 320) and mousexy[1] > 150 and mousexy[1] < (150 + 100):
                    HTPtext = "on"
            elif Ttext == "on" and HTPtext == "on":
                if mousexy[0] > 520 and mousexy[0] < (520 + 125) and mousexy[1] > 438 and mousexy[1] < (438 + 50):
                    HTPtext = "off"
                
    if Ttext == "on":
        screen.blit(Title_Galaxy, (0, 0))
        screen.blit(titletextSurface, titletextRect)
        screen.blit(title2textSurface, title2textRect)
        pygame.draw.rect(screen, WHITE, (270, 150, 360, 100), 5)
        screen.blit(HTPtextSurface, HTPtextRect)
        # Each individual score (tedious but working version)
        pygame.draw.rect(screen, WHITE, (20, 140 , 175, 240), 5)
        toptextSurface = topfont.render("Top Scores:", True, WHITE)
        screen.blit(toptextSurface, toptextRect)
        S1textSurface = S1font.render(("1:        " +(str(all_scoreslist2[0]))), True, WHITE)
        screen.blit(S1textSurface, S1textRect)
        S2textSurface = S2font.render(("2:       " +(str(all_scoreslist2[1]))), True, WHITE)
        screen.blit(S2textSurface, S2textRect)
        S3textSurface = S3font.render(("3:       " +(str(all_scoreslist2[2]))), True, WHITE)
        screen.blit(S3textSurface, S3textRect)
        S4textSurface = S4font.render(("4:       " +(str(all_scoreslist2[3]))), True, WHITE)
        screen.blit(S4textSurface, S4textRect)
        S5textSurface = S5font.render(("5:       " +(str(all_scoreslist2[4]))), True, WHITE)
        screen.blit(S5textSurface, S5textRect)
        S6textSurface = S6font.render(("6:       " +(str(all_scoreslist2[5]))), True, WHITE)
        screen.blit(S6textSurface, S6textRect)
        S7textSurface = S7font.render(("7:       " +(str(all_scoreslist2[6]))), True, WHITE)
        screen.blit(S7textSurface, S7textRect)
        S8textSurface = S8font.render(("8:       " +(str(all_scoreslist2[7]))), True, WHITE)
        screen.blit(S8textSurface, S8textRect)
        S9textSurface = S9font.render(("9:       " +(str(all_scoreslist2[8]))), True, WHITE)
        screen.blit(S9textSurface, S9textRect)
        S10textSurface = S10font.render(("10:      " +(str(all_scoreslist2[9]))), True, WHITE)
        screen.blit(S10textSurface, S10textRect)
        if HTPtext == "on":
            screen.blit(How_to_Play, (0, 0))
            pygame.draw.rect(screen, BLACK, (520, 438, 125, 50), 5)
    else:
        screen.blit(Galaxy, (0, 0))

    if Ptext == "on":
        screen.blit(textSurfaceObj, textRectObj)
 
    # If game is not paused
    if carryOn:
        #pygame.mixer.pause()

        Ship_sensor = {'rect': pygame.Rect(playerCar.rect.x + 16, playerCar.rect.y + 5, 50, 73)}

        A1 = {'rect': pygame.Rect(car1.rect.x + 60, car1.rect.y + 100, 36, 33)}
        A2 = {'rect': pygame.Rect(car2.rect.x + 60, car2.rect.y + 100, 36, 33)}
        A3 = {'rect': pygame.Rect(car3.rect.x + 60, car3.rect.y + 100, 36, 33)}
        A4 = {'rect': pygame.Rect(car4.rect.x + 60, car4.rect.y + 100, 36, 33)}

        Power_up_y += 5
        Power_up = {'rect': pygame.Rect(Power_up_x, Power_up_y, 50, 60)}

        asteroids = []
        if Rem1_rect == False:
            asteroids.append(A1)
        if Rem2_rect == False:
            asteroids.append(A2)
        if Rem3_rect == False:
            asteroids.append(A3)
        if Rem4_rect == False:
            asteroids.append(A4)

        # Beam collision
        for beam in beams[:]:
            if doRectsOverlap(A1['rect'], beam):
                beams.remove(beam)
                Rem1_rect = True
                Rem1_image = True
                SCORE += 100
                Crunch.play()
            elif doRectsOverlap(A2['rect'], beam):
                beams.remove(beam)
                Rem2_rect = True
                Rem2_image = True
                SCORE += 100
                Crunch.play()
            elif doRectsOverlap(A3['rect'], beam):
                beams.remove(beam)
                Rem3_rect = True
                Rem3_image = True
                SCORE += 100
                Crunch.play()
            elif doRectsOverlap(A4['rect'], beam):
                beams.remove(beam)
                Rem4_rect = True
                Rem4_image = True
                SCORE += 100
                Crunch.play()
    ##        elif doRectsOverlap(Ship_sensor['rect'], beam):
    ##            beams.remove(beam)

        # Asteroid collision
        if doRectsOverlap(A1['rect'], Ship_sensor["rect"]):
            if Rem1_rect == False and Rem1_image == False:
                if LIVES >= 0:
                    LIVES -= 1
                else:
                    LIVES = 3
            Rem1_rect = True
            Rem1_image = True
        if doRectsOverlap(A2['rect'], Ship_sensor["rect"]):
            if Rem2_rect == False and Rem2_image == False:
                if LIVES >= 0:
                    LIVES -= 1
                else:
                    LIVES = 3
            Rem2_rect = True
            Rem2_image = True
        if doRectsOverlap(A3['rect'], Ship_sensor["rect"]):
            if Rem3_rect == False and Rem3_image == False:
                if LIVES >= 0:
                    LIVES -= 1
                else:
                    LIVES = 3
            Rem3_rect = True
            Rem3_image = True
        if doRectsOverlap(A4['rect'], Ship_sensor["rect"]):
            if Rem4_rect == False and Rem4_image == False:
                if LIVES >= 0:
                    LIVES -= 1
                else:
                    LIVES = 3
            Rem4_rect = True
            Rem4_image = True
        if doRectsOverlap(Ship_sensor["rect"], Power_up["rect"]):
            Collect.play()
            if RemPU_rect == False:
                Power_up_x = random.randrange(5, 631)
                Power_up_y = -5000
                if PU_type == 1:
                    TIME += 500
            RemPU_rect = False

        if LIVES <= 0:
            LIVES = 3
            Lose.play()
            Check_scores2()
            Title_screen()

        # Showing the hitboxes.
        for i in range(len(beams)):
            beams[i][1] -= 20
    ##        pygame.draw.rect(screen, RED, beams[i])
    ##        if beams[i][1] >= -60:
    ##            beams.remove(beam)

##        for h in range(len(asteroids)):
##             pygame.draw.rect(screen, WHITE, asteroids[h]['rect'])
##
##        pygame.draw.rect(screen, BLUE, Ship_sensor['rect'])
##
##        pygame.draw.rect(screen, GREEN, Power_up['rect'])
        if PU_type == 1:
            screen.blit(Time_Up, (Power_up_x - 5, Power_up_y - 5))

        SCORE += speed_points

        if TIME <= 0:
            carryOn = False
            timeout = True
            if SCORE > 0:
                Win.play()
            else:
                Lose.play()
            Check_scores2()
            Title_screen()
        else:
            TIME -= 1

        # Controls
        if key[pygame.K_a]:
            playerCar.moveLeft(5)
        if key[pygame.K_d]:
             playerCar.moveRight(5)
        if key[pygame.K_w] and traffic_speedy <= 2.5:
            traffic_speedy += 0.02
            speed_points += 0.01
        if key[pygame.K_s] and traffic_speedy >= -1.5:
            traffic_speedy -= 0.02
            speed_points -= 0.01

        # Game Logic
        for car in all_coming_cars:
            car.moveForward(traffic_speedy)

        for beam in rect_beams:
            beam.moveForward(20)

        if car1.rect.y > SCREENHEIGHT:
            car1.changeSpeed(random.randint(50, 100))
            car1.rect.y = -200
            if Rem1_image == False:
                SCORE -= 200
            Rem1_rect = False
            Rem1_image = False
        if car2.rect.y > SCREENHEIGHT:
            car2.changeSpeed(random.randint(50, 100))
            car2.rect.y = -200
            if Rem2_image == False:
                SCORE -= 200
            Rem2_rect = False
            Rem2_image = False
        if car3.rect.y > SCREENHEIGHT:
            car3.changeSpeed(random.randint(50, 100))
            car3.rect.y = -200
            if Rem3_image == False:
                SCORE -= 200
            Rem3_rect = False
            Rem3_image = False
        if car4.rect.y > SCREENHEIGHT:
            car4.changeSpeed(random.randint(50, 100))
            car4.rect.y = -200
            if Rem4_image == False:
                SCORE -= 200
            Rem4_rect = False
            Rem4_image = False
        if Power_up_y > SCREENHEIGHT:
            Power_up_x = random.randrange(5, 631)
            Power_up_y = -2000
            RemPU_rect = False

        for tree in all_coming_decor:
            tree.moveForward(decor_speedy)
            if tree.rect.y > SCREENHEIGHT + 500:
                tree.rect.y = -1000

        ## Collision
        if playerCar.rect.x >= 549 and touchingwall == 0:
            touchingwall = 1
        elif playerCar.rect.x <= 0 and touchingwall == 0:
            touchingwall = 1
        elif playerCar.rect.x > 0 and playerCar.rect.x < 519:
            touchingwall = 0

        all_coming_decor.update()
        all_coming_decor.draw(screen)
        rect_beams.update()
        rect_beams.draw(screen)
        if RemP_image == False:
            playerCar_list.update()
            playerCar_list.draw(screen)
        if Rem1_image == False:
            car1_list.update()
            car1_list.draw(screen)
        if Rem2_image == False:
            car2_list.update()
            car2_list.draw(screen)
        if Rem3_image == False:
            car3_list.update()
            car3_list.draw(screen)
        if Rem4_image == False:
            car4_list.update()
            car4_list.draw(screen)

        timetextSurface = timefont.render(("Time: " +(str(TIME))), True, WHITE)
        scoretextSurface = scorefont.render(("Score: " +(str(int(SCORE)))), True, WHITE)
        livestextSurface = livesfont.render(("Lives: " +(str(LIVES))), True, WHITE)
    else:
        pygame.mixer.unpause()

    screen.blit(timetextSurface, timetextRect)
    screen.blit(scoretextSurface, scoretextRect)
    screen.blit(livestextSurface, livestextRect)

    # Refresh Screen
    pygame.display.flip()

    # FPS
    clock.tick(60)

pygame.quit()

